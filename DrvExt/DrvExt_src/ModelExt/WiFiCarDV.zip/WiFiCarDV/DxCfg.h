#ifndef _DXCFG_H
#define _DXCFG_H

#define USB_CHARGE_FUNCTION             DISABLE
#define TV_SWITCH_FUNCTION              DISABLE
#define GPIO_DUMMYLOAD_FUNCTION         DISABLE

#endif
