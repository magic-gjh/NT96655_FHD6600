#ifndef _PINMUXCFG_H
#define _PINMUXCFG_H

#include "IOInit.h"

#endif //_PINMUXCFG_H