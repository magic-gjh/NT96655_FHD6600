#ifndef _IPL_MODE_IMX322LQJ_EVB_FF_INT_H_
#define _IPL_MODE_IMX322LQJ_EVB_FF_INT_H_
/**
    IPL_Mode_IMX322LQJ_EVB_FF_Int.h


    @file       IPL_Mode_IMX322LQJ_EVB_FF_Int.h
    @ingroup    mISYSAlg
    @note       Nothing (or anything need to be mentioned).

    Copyright   Novatek Microelectronics Corp. 2011.  All rights reserved.
*/

IPL_CMD_CHGMODE_FP IPL_GetModeFp(IPL_MODE CurMode, IPL_MODE NextMode);

#endif //_IPL_MODE_IMX322LQJ_INT_H_